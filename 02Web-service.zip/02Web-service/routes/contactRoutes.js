const express = require('express');
const path = require('path')
const router = express.Router();

router.route("/").get((request, response) => {
    response.sendFile(path.join(__dirname, "../Front_end/views/auth.html"))
});

module.exports = router