var express = require('express')
var path = require('path')
var server = express()
var readBody = express.urlencoded({extended: false})

server.use(express.static(path.join(__dirname, "Front_end")))
server.use(express.static(path.join(__dirname, "Front_end/public")))
server.use(express.static(path.join(__dirname, "Front_end/Asset/fonts")))
server.use(express.static(path.join(__dirname, "Front_end/Asset/images")))
//server.use(express.static(path.join(__dirname, "Front_end/views")))

server.use("/", require("./routes/contactRoutes"))

server.post("/", readBody, checkPassword)

function checkPassword(request, response) {
    response.send(request.body)
}

server.listen(8000)