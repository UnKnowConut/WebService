const path = require('path')

/*******************************************************************************
 * Function   :     Getauthview
 * Route      :     GET /login
 * Access     :     Public
 * Description:     Show login view to user
 ******************************************************************************/
const Getauthview = (request, response) => { //Anonymous + Arrow Function
    response.sendFile(path.join(__dirname, "../Front_end/views/auth.html"))
}

//Export function
module.exports = {Getauthview}