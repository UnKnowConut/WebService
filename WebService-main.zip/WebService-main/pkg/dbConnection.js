const mongoose = require("mongoose")
const CONFIG = require('../config/loadconfig')

const connectDb = () => {
    try {
        mongoose.connect(CONFIG().CONN_STR)
        console.log("DataBase Connection . . .")
    }
    catch (err) {
        //Error Handle
        console.log("Error DataBase Connection : " + err)
    }
}

module.exports = {connectDb}