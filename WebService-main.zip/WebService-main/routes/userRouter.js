const express = require('express');
const router = express.Router();

/* Import user controller[Business logic] */
const {
    Getauthview
} = require("../controllers/userController")

/* Route */
router.route("/login").get(Getauthview);

/* Export Route to server.js */
module.exports = router