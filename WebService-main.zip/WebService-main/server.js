var express = require('express')
var path = require('path')
var server = express()
var readBody = express.urlencoded({extended: false})

server.use(express.static(path.join(__dirname, "Front_end")))

/* Frontend content */
server.use("/", require("./routes/userRouter"))

server.post("/login", readBody, checkPassword)

function checkPassword(request, response) {
    response.send(request.body)
}

server.listen(8000)