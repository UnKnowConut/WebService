/* Import */
var express  = require('express')
var path     = require('path')
const CONFIG = require('./config/loadconfig')

/* Create server */
var server   = express()

server.use(express.static(path.join(__dirname, "Front_end")))

server.use("/", require("./routes/userRouter"))

server.listen(CONFIG().PORT_APP)